# OPsign – Installation per Webseite

Nach jedem Push auf `main` baut GitHub die App, signiert sie mit deinem Zertifikat
und veröffentlicht eine Installationsseite auf GitHub Pages:
https://DEIN-NAME.github.io/DEIN-REPO/

## Einmalig einrichten
1. Repo → Settings → Pages → Source: **GitHub Actions**
2. Repo → Settings → Secrets and variables → Actions → diese 4 Secrets anlegen:
   - `P12_BASE64`      Zertifikat (.p12) als Base64:  `base64 -i cert.p12 | pbcopy`
   - `P12_PASSWORD`    Passwort des .p12
   - `PROFILE_BASE64`  Provisioning Profile (.mobileprovision) als Base64
   - `BUNDLE_ID`       Bundle-ID, die zum Profil passt (z. B. com.deinname.opsign)
3. Push auf `main` (oder Actions → Run workflow)

## Hinweis
Das Profil muss die UDID des Geräts enthalten (Developer-Account) oder ein Enterprise-Profil sein.
Repo muss öffentlich sein, damit GitHub Pages mit kostenlosem Account funktioniert.
