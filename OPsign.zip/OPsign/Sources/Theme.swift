import SwiftUI

enum Theme {
    static let black = Color(red: 0.02, green: 0.03, blue: 0.06)
    static let navy = Color(red: 0.05, green: 0.10, blue: 0.26)
    static let blue = Color(red: 0.12, green: 0.30, blue: 0.75)
    static let card = Color(red: 0.07, green: 0.11, blue: 0.22)
    static let background = LinearGradient(
        colors: [black, navy], startPoint: .top, endPoint: .bottom)
}
