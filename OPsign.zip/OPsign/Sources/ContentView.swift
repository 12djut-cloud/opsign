import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var tab = 0

    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(Theme.black)
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }

    var body: some View {
        TabView(selection: $tab) {
            SignView()
                .tabItem { Label("Signieren", systemImage: "signature") }.tag(0)
            LibraryView()
                .tabItem { Label("Bibliothek", systemImage: "square.stack.3d.up") }.tag(1)
            CertsView()
                .tabItem { Label("Zertifikate", systemImage: "checkmark.seal") }.tag(2)
        }
        .accentColor(Theme.blue)
    }
}

struct SignView: View {
    @State private var showPicker = false
    @State private var ipaName: String?

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 24) {
                Image(systemName: "signature")
                    .font(.system(size: 64, weight: .bold))
                    .foregroundColor(Theme.blue)
                Text("OPsign")
                    .font(.system(size: 36, weight: .heavy))
                    .foregroundColor(.white)
                Text(ipaName ?? "Wähle eine .ipa zum Signieren")
                    .foregroundColor(.white.opacity(0.7))

                Button { showPicker = true } label: {
                    Label("IPA auswählen", systemImage: "doc.badge.plus")
                        .frame(maxWidth: .infinity).padding()
                        .background(Theme.card).cornerRadius(14)
                }
                Button { /* Signier-Engine kommt als nächster Schritt */ } label: {
                    Text("Signieren")
                        .bold().frame(maxWidth: .infinity).padding()
                        .background(Theme.blue).cornerRadius(14)
                }
                .disabled(ipaName == nil)
                .opacity(ipaName == nil ? 0.4 : 1)
            }
            .foregroundColor(.white)
            .padding(24)
        }
        .fileImporter(isPresented: $showPicker,
                      allowedContentTypes: [UTType(filenameExtension: "ipa") ?? .data]) { result in
            if case .success(let url) = result { ipaName = url.lastPathComponent }
        }
    }
}

struct LibraryView: View {
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            Text("Noch keine signierten Apps")
                .foregroundColor(.white.opacity(0.7))
        }
    }
}

struct CertsView: View {
    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            Text("Zertifikate (.p12) und Profile (.mobileprovision) kommen hierher")
                .multilineTextAlignment(.center)
                .foregroundColor(.white.opacity(0.7))
                .padding()
        }
    }
}
